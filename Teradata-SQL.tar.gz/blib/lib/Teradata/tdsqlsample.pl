#!perl
use Teradata::SQL;

$dbh = Teradata::SQL::connect("demotdat/sysdba,sysdba")
 or die "Could not connect: $!";

$sth = $dbh->open("select * from dbc.Tables
 sample 10  order by 1,2")  or die "Could not open";

while (@r = $sth->fetchrow_list) {
 print "row: @r\n";
}
$sth->close();

$dbh->disconnect;
